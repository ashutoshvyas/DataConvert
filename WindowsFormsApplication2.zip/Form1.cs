﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            MySqlConnection con = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQLSysConnectionString"].ConnectionString);
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "show databases";
            try
            {
                progressBar1.Value = 10;
                lblStatus.Text = "Connecting to MySQL Server";
                con.Open();
                lblStatus.Text = "Fetching Databases list";
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string row = "";
                    for (int i = 0; i < reader.FieldCount; i++)
                        row += reader.GetValue(i).ToString();
                    listBox1.Items.Add(row);
                    if (progressBar1.Value == 90)
                        progressBar1.Value = Math.Min(100, progressBar1.Value + 1);
                    else
                        progressBar1.Value = Math.Min(100, progressBar1.Value + 10);

                    lblStatus.Text = "Loading Databases to list";
                }

                progressBar1.Value = 100;
                Application.DoEvents();

                lblStatus.Text = "Load Complete !!";
            }

            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Number.ToString());
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            MySqlConnection con = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQLConnectionString"].ConnectionString + listBox1.SelectedItem.ToString() + ";");
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SHOW FULL TABLES IN " + listBox1.SelectedItem.ToString() + " WHERE TABLE_TYPE NOT LIKE 'VIEW'";
            try
            {
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string row = "";
                    //for (int i = 0; i < reader.FieldCount; i++)
                    row += reader.GetValue(0).ToString();
                    listBox2.Items.Add(row);
                }


            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Number.ToString());
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            MySqlConnection con = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQLConnectionString"].ConnectionString + listBox1.SelectedItem.ToString() + ";");
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "show columns from " + listBox2.SelectedItem.ToString();
            try
            {
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    List<String> itemList = new List<string>();

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        itemList.Add(reader.GetValue(i).ToString());
                    }

                    ListViewItem item = new ListViewItem(itemList.ToArray());

                    listView1.Items.Add(item);
                }


            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Number.ToString());
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Create this database in SQL Server
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["SQLConnectionStringMaster"].ConnectionString);

            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Create Database " + listBox1.SelectedItem.ToString();
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Database Created Successfully"); ;

                //Right now create the custom is null function also
                String functionString = "CREATE FUNCTION customisnull(@val VARCHAR(MAX)) RETURNS BIT AS BEGIN DECLARE @retVal BIT SET @retVal = CASE WHEN @val IS NULL THEN 0 ELSE 1 END return @retVal END";

                SqlConnection con2 = new SqlConnection(ConfigurationManager.ConnectionStrings["SQLConnectionString"].ConnectionString + listBox1.SelectedItem.ToString() + "; ");

                SqlCommand cmd2 = con2.CreateCommand();
                cmd2.CommandText = functionString;
                con2.Open();
                cmd2.ExecuteNonQuery();
                con2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();

            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Create tables.
            MySqlConnection con = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQLConnectionString"] + listBox1.SelectedItem.ToString() + ";");
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SHOW FULL TABLES IN " + listBox1.SelectedItem.ToString() + " WHERE TABLE_TYPE NOT LIKE 'VIEW'";
            try
            {
                lblStatus.Text = "Connecting to MySQl Databases";
                progressBar1.Value = 10;
                con.Open();
                lblStatus.Text = "Connected ! Fetching tables";
                progressBar1.Value = 20;

                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string row = "";
                    //for (int i = 0; i < reader.FieldCount; i++)
                    row += reader.GetValue(0).ToString();

                    //Pass this table name to a function
                    lblStatus.Text = "Creating Table " + row;
                    CreateSQLTable(row);
                    if (progressBar1.Value == 80)
                        progressBar1.Value = progressBar1.Value + 2;
                    else
                        progressBar1.Value = Math.Min(100, progressBar1.Value + 10);

                }

                Application.DoEvents();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void CreateSQLTable(string row)
        {
            SqlConnection con = new SqlConnection("Server=.\\PANDA;Database=" + listBox1.SelectedItem.ToString() + ";User Id=sa;Password=P4nd4123; ");
            SqlCommand cmd = con.CreateCommand();
            String commandText = "Create Table " + row;
            commandText += "(";
            commandText += GetColumnsWithDataTypes(row);
            commandText += ")";

            cmd.CommandText = commandText;
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                //MessageBox.Show("Table " + row + " Created Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private string GetColumnsWithDataTypes(string row)
        {
            String commandText = "";
            MySqlConnection con = new MySqlConnection("Server=127.0.0.1;Uid=root;Pwd=Password!23;Database=" + listBox1.SelectedItem.ToString() + ";");
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "show columns from " + row;
            try
            {
                String primaryKeyString = "";
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    List<String> itemList = new List<string>();

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                commandText += "[" + reader.GetValue(i).ToString() + "] ";
                                break;
                            case 1:
                                commandText += GetConvertedDataType(reader.GetValue(0).ToString(), reader.GetValue(i).ToString()) + " ";
                                break;
                            case 2:
                                commandText += reader.GetValue(i).ToString() == "NO" ? "NOT NULL " : " ";
                                break;
                            case 3:
                                if (reader.GetValue(i).ToString() == "PRI")
                                    primaryKeyString = "PRIMARY KEY (" + reader.GetValue(0).ToString() + ")";
                                break;
                            default:
                                if (i == reader.FieldCount - 1)
                                    commandText += ", ";
                                break;
                        }
                    }
                }

                commandText += " " + primaryKeyString + " ";

                return commandText;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Number.ToString());
                MessageBox.Show(ex.Message);
                return String.Empty;
            }
            finally
            {
                con.Close();
            }
        }

        private string GetConvertedDataType(string colName, string v)
        {
            if (v.StartsWith("smallint") || v.StartsWith("mediumint") || v.StartsWith("int"))
                return "INT";
            else if (v.StartsWith("timestamp"))
                return "DATETIME";
            else if (v.StartsWith("tinyint"))
                return "TINYINT";
            else if (v.StartsWith("year"))
                return "SMALLINT";
            else if (v.StartsWith("float"))
                return v.Replace("float", "decimal");
            else if (v.StartsWith("enum"))
                return ConvertEnum(colName, v);
            else if (v.StartsWith("mediumtext"))
                return "NVARCHAR(MAX)";
            else if (v.StartsWith("double"))
                return "float";
            else if (v.StartsWith("set")) //This is not 100% correct but largely this would work
                throw new Exception("SET Data Type Encoundered. Unable to convert database.");
            else if (v.StartsWith("blob") || v.StartsWith("longblob") || v.StartsWith("mediumblob"))
                return "VARBINARY(MAX)";
            else
                return v;
        }

        private string ConvertEnum(String colName, string v)
        {
            String enumValues = v.StartsWith("enum") ? v.Substring(4) : v.Substring(3); //Its either ENUM or SET
            //Find the maxlength of all values
            String[] strvalue = enumValues.Split(',');
            Int32 maxLength = strvalue.Max(x => x.Length);
            return "VARCHAR(" + maxLength + ") CHECK (" + colName + " IN " + enumValues + ")";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedItems.Count > 0)
                CopyDataFromSelectedTables();
            else
                CopyDataFromAllTables();
        }

        private void CopyDataFromSelectedTables()
        {
            progressBar1.Value = 0;
            progressBar1.Maximum = 100;
            progressBar1.Minimum = 0;

            //Fetch All Data
            MySqlConnection con = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQLConnectionString"] + listBox1.SelectedItem.ToString() + ";");
            SqlConnection sqlcon = new SqlConnection("Server=.\\PANDA;Database=" + listBox1.SelectedItem.ToString() + ";User Id=sa;Password=P4nd4123; ");
            try
            {
                con.Open();
                foreach (var item in listBox2.SelectedItems)
                {
                    string row = "";
                    //for (int i = 0; i < reader.FieldCount; i++)
                    row += item.ToString();

                    //Pass this table name to a function
                    lblStatus.Text = "Copyng Data for " + row;

                    MySqlDataAdapter da = new MySqlDataAdapter();

                    DataSet ds = null;
                    try
                    {
                        Boolean partial = true;
                        Int32 counter = 0;
                        while (partial == true)
                        {
                            counter = PerformWork(sqlcon, row, out da, out ds, out partial, counter);

                        }

                        progressBar1.PerformStep();

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error Importing Data from " + row);
                    }

                    //Set some cooling off for the database so that memory can be flushed.
                    System.Threading.Thread.Sleep(500);



                }

                progressBar1.Value = 100;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Number.ToString());
                MessageBox.Show(ex.Message);
            }
        }

        private int PerformWork(SqlConnection sqlcon, string row, out MySqlDataAdapter da, out DataSet ds, out bool partial, int counter)
        {
            ds = FetchAllData(row, counter, out da, out partial);
            String sqlQ = String.Empty;

            if (da.SelectCommand.CommandText.Contains("OFFSET"))
                sqlQ = "Select * FROM " + row + " EXCEPT SELECT TOP(" + counter + ") FROM " + row;
            else
                sqlQ = da.SelectCommand.CommandText;

            SqlDataAdapter daa = new SqlDataAdapter(sqlQ, sqlcon);
            Int32 up = daa.Update(ds);

            //Put this into SQL
            SqlBulkCopy bulk = new SqlBulkCopy(sqlcon);
            bulk.DestinationTableName = row;
            foreach (DataColumn col in ds.Tables[0].Columns)
                bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);


            sqlcon.Open();
            bulk.WriteToServer(ds.Tables[0]);
            sqlcon.Close();

            counter += 20000;
            return counter;
        }

        private void CopyDataFromAllTables()
        {
            progressBar1.Value = 0;
            progressBar1.Maximum = 100;
            progressBar1.Minimum = 0;

            //Fetch All Data
            MySqlConnection con = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQLConnectionString"] + listBox1.SelectedItem.ToString() + ";");
            SqlConnection sqlcon = new SqlConnection("Server=.\\PANDA;Database=" + listBox1.SelectedItem.ToString() + ";User Id=sa;Password=P4nd4123; ");
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SHOW FULL TABLES IN " + listBox1.SelectedItem.ToString() + " WHERE TABLE_TYPE NOT LIKE 'VIEW'";
            try
            {
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                progressBar1.Step = (100 / reader.FieldCount);

                while (reader.Read())
                {
                    string row = "";
                    row += reader.GetValue(0).ToString();

                    //Pass this table name to a function
                    lblStatus.Text = "Copying Data for " + row;

                    MySqlDataAdapter da = new MySqlDataAdapter();

                    DataSet ds = null;

                    try
                    {
                        Boolean partial = true;
                        Int32 counter = 0;
                        while (partial == true)
                        {
                            ds = FetchAllData(row, counter, out da, out partial);
                            SqlDataAdapter daa = new SqlDataAdapter(da.SelectCommand.CommandText, sqlcon);

                            Int32 up = daa.Update(ds);


                            //Put this into SQL
                            SqlBulkCopy bulk = new SqlBulkCopy(sqlcon);
                            bulk.DestinationTableName = row;
                            foreach (DataColumn col in ds.Tables[0].Columns)
                                bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);


                            sqlcon.Open();
                            bulk.WriteToServer(ds.Tables[0]);
                            sqlcon.Close();

                            counter += 20000;
                        }
                        progressBar1.PerformStep();

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error Importing Data from " + ds.Tables[0].TableName);
                    }

                    //Set some cooling off for the database so that memory can be flushed.
                    System.Threading.Thread.Sleep(500);

                }

                progressBar1.Value = 100;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Number.ToString());
                MessageBox.Show(ex.Message);
            }
        }

        private DataSet FetchAllData(string row, Int32 counter, out MySqlDataAdapter da, out Boolean partial)
        {
            MySqlConnection con = new MySqlConnection("Server=127.0.0.1;Uid=root;Pwd=Password!23;Database=" + listBox1.SelectedItem.ToString() + ";");
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Select COUNT(*) from " + row;
            MySqlDataAdapter da2 = new MySqlDataAdapter(cmd);
            da2 = new MySqlDataAdapter(cmd.CommandText, con);
            try
            {
                con.Open();
                DataSet ds2 = new DataSet();
                da2.Fill(ds2);

                //This ds has count only.
                if (Convert.ToInt32(ds2.Tables[0].Rows[0][0]) > 20000)
                {
                    //Break it into multiple loops
                    partial = true;
                    if (Convert.ToInt32(ds2.Tables[0].Rows[0][0]) < (counter + 20000))
                        partial = false;
                }
                else
                    partial = false;


                //Now setup database again.
                MySqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandText = "Select * from " + row + " LIMIT 20000 OFFSET " + counter;
                da = new MySqlDataAdapter(cmd2.CommandText, con);
                DataSet ds = new DataSet();
                da.Fill(ds);


                return ds;
            }
            catch (MySqlException ex)
            {
                da = null;
                partial = false;
                MessageBox.Show(ex.Number.ToString());
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Create tables.
            MySqlConnection con = new MySqlConnection("Server=127.0.0.1;Uid=root;Pwd=Password!23;Database=" + listBox1.SelectedItem.ToString() + ";");
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SHOW FULL TABLES IN " + listBox1.SelectedItem.ToString() + " WHERE TABLE_TYPE LIKE 'VIEW'";
            try
            {
                lblStatus.Text = "Connecting to MySQl Databases";
                progressBar1.Value = 10;
                con.Open();
                lblStatus.Text = "Connected ! Fetching Views";
                progressBar1.Value = 20;

                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string row = "";
                    //for (int i = 0; i < reader.FieldCount; i++)
                    row = reader.GetValue(0).ToString();

                    //Pass this table name to a function
                    lblStatus.Text = "Creating View " + row;
                    String viewDefiniton = GetViewDefinitionFromMySQL(row);
                    CreateSQLView(viewDefiniton);
                    if (progressBar1.Value == 80)
                        progressBar1.Value = progressBar1.Value + 2;
                    else
                        progressBar1.Value = Math.Min(100, progressBar1.Value + 10);

                }

                Application.DoEvents();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Number.ToString());
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private string GetViewDefinitionFromMySQL(string viewName)
        {
            //Create tables.
            MySqlConnection con = new MySqlConnection("Server=127.0.0.1;Uid=root;Pwd=Password!23;Database=" + listBox1.SelectedItem.ToString() + ";");
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SHOW CREATE VIEW " + viewName;
            try
            {
                con.Open();

                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string row = "";
                    //for (int i = 0; i < reader.FieldCount; i++)
                    row = reader.GetValue(1).ToString();
                    return row;

                }

                return null;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Number.ToString());
                MessageBox.Show(ex.Message);
                return null;
            }
            finally
            {
                con.Close();
            }
        }

        private void CreateSQLView(string viewDefinition)
        {
            //ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER 
            viewDefinition = viewDefinition.Replace("ALGORITHM=UNDEFINED DEFINER=", "");
            viewDefinition = viewDefinition.Replace("SQL SECURITY DEFINER", "");
            viewDefinition = viewDefinition.Replace("`", "");
            viewDefinition = viewDefinition.Replace("root@localhost", ""); //This will need to be changed if the server creds and location are different.
            viewDefinition = viewDefinition.Replace("isnull(", "dbo.customisnull(");
            viewDefinition = viewDefinition.Replace("ifnull", "isnull");

            SqlConnection con = new SqlConnection("Server=.\\PANDA;Database=" + listBox1.SelectedItem.ToString() + ";User Id=sa;Password=P4nd4123; ");
            SqlCommand cmd = con.CreateCommand();
            String commandText = viewDefinition;
            //commandText += "(";
            //commandText += GetColumnsWithDataTypes(row);
            //commandText += ")";

            cmd.CommandText = commandText;
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                //MessageBox.Show("Table " + row + " Created Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

    }
}
